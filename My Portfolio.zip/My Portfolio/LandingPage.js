window.addEventListener("DOMContentLoaded", function() {
    const multiText = document.querySelector(".multiText");
    const texts = ["Icarl", "Velasquez", "Cadavos"];
    let currentTextIndex = 0;
    let intervalId = null;

    function changeText() {
        multiText.textContent = texts[currentTextIndex];
        currentTextIndex = (currentTextIndex + 1) % texts.length;
    }

    function isInViewport(element) {
        const rect = element.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight)
        );
    }

    function addActiveClass() {
        if (isInViewport(multiText)) {
            multiText.classList.add("active");
            if (!intervalId) {
                intervalId = setInterval(changeText, 2000); // Change text every 2 seconds
            }
        } else {
            multiText.classList.remove("active");
            clearInterval(intervalId);
            intervalId = null;
        }
    }

    window.addEventListener("scroll", addActiveClass);
    window.addEventListener("resize", addActiveClass);

    // Trigger the initial check when the page loads
    addActiveClass();
});

// ABOUT SECTION
function revealParagraph() {
    var reveals = document.querySelectorAll('.about-Paragraph');
  
    for (var i = 0; i < reveals.length; i++) {
      var windowHeight = window.innerHeight;
      var revealTop = reveals[i].getBoundingClientRect().top;
      var revealPoint = 150;
  
      if (revealTop < windowHeight - revealPoint) {
        reveals[i].classList.add('active');
      } else {
        reveals[i].classList.remove('active');
      }
    }
}

window.addEventListener('scroll', revealParagraph);
window.addEventListener('DOMContentLoaded', revealParagraph);

function revealHeading() {
    var reveals = document.querySelectorAll('#about-Section h2');
  
    for (var i = 0; i < reveals.length; i++) {
      var windowHeight = window.innerHeight;
      var revealTop = reveals[i].getBoundingClientRect().top;
      var revealPoint = 150;
  
      if (revealTop < windowHeight - revealPoint) {
        reveals[i].classList.add('active');
      } else {
        reveals[i].classList.remove('active');
      }
    }
  }
  
  window.addEventListener('scroll', revealHeading);
  window.addEventListener('DOMContentLoaded', revealHeading);
  
  function revealButton() {
    var reveals = document.querySelectorAll('.read-Button');
  
    for (var i = 0; i < reveals.length; i++) {
      var windowHeight = window.innerHeight;
      var revealTop = reveals[i].getBoundingClientRect().top;
      var revealPoint = 150;
  
      if (revealTop < windowHeight - revealPoint) {
        reveals[i].classList.add('active');
      } else {
        reveals[i].classList.remove('active');
      }
    }
  }
  
  window.addEventListener('scroll', revealButton);
  window.addEventListener('DOMContentLoaded', revealButton);

  //WEBSITE PROJECTS

  function revealHeading1() {
    var reveals = document.querySelectorAll('#project-Section h2');
  
    for (var i = 0; i < reveals.length; i++) {
      var windowHeight = window.innerHeight;
      var revealTop = reveals[i].getBoundingClientRect().top;
      var revealPoint = 150;
  
      if (revealTop < windowHeight - revealPoint) {
        reveals[i].classList.add('active');
      } else {
        reveals[i].classList.remove('active');
      }
    }
  }
  
  window.addEventListener('scroll', revealHeading1);
  window.addEventListener('DOMContentLoaded', revealHeading1);

  function revealProjects() {
    var reveals = document.querySelectorAll('.project-container');
  
    for (var i = 0; i < reveals.length; i++) {
      var windowHeight = window.innerHeight;
      var revealTop = reveals[i].getBoundingClientRect().top;
      var revealPoint = 150;
  
      if (revealTop < windowHeight - revealPoint) {
        reveals[i].classList.add('active');
      } else {
        reveals[i].classList.remove('active');
      }
    }
}

window.addEventListener('scroll', revealProjects);
window.addEventListener('DOMContentLoaded', revealProjects);

  //CONTACTS PROJECTS

  function revealHeading2() {
    var reveals = document.querySelectorAll('#contact-Section h2');
  
    for (var i = 0; i < reveals.length; i++) {
      var windowHeight = window.innerHeight;
      var revealTop = reveals[i].getBoundingClientRect().top;
      var revealPoint = 150;
  
      if (revealTop < windowHeight - revealPoint) {
        reveals[i].classList.add('active');
      } else {
        reveals[i].classList.remove('active');
      }
    }
  }
  
  window.addEventListener('scroll', revealHeading2);
  window.addEventListener('DOMContentLoaded', revealHeading2);

  /*REVEAL FORMS */
  function revealForms() {
    var reveals = document.querySelectorAll('.form-container');
  
    for (var i = 0; i < reveals.length; i++) {
      var windowHeight = window.innerHeight;
      var revealTop = reveals[i].getBoundingClientRect().top;
      var revealPoint = 150;
  
      if (revealTop < windowHeight - revealPoint) {
        reveals[i].classList.add('active');
      } else {
        reveals[i].classList.remove('active');
      }
    }
}

window.addEventListener('scroll', revealForms);
window.addEventListener('DOMContentLoaded', revealForms);